// ═══════════════════════════════════════════════════════
// INTENTIONAL BEAUTY — MAIN JS
// Intentional Group Ltd · intentionalgroup.com
// ═══════════════════════════════════════════════════════

// ── HEADER SCROLL ──
const header = document.getElementById('header');
window.addEventListener('scroll', () => {
  header.classList.toggle('scrolled', window.scrollY > 60);
});

// ── HAMBURGER MENU ──
const hamburger = document.getElementById('hamburger');
const mobileNav = document.getElementById('mobileNav');
hamburger?.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  mobileNav.classList.toggle('open');
});
document.querySelectorAll('.mobile-nav a').forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    mobileNav.classList.remove('open');
  });
});

// ── HERO IMAGE ANIMATION ──
const heroImage = document.querySelector('.hero-image');
if (heroImage) {
  setTimeout(() => heroImage.classList.add('loaded'), 100);
}

// ── CONTACT FORM ──
// TO ACTIVATE EmailJS:
// 1. Sign up free at emailjs.com
// 2. Replace YOUR_SERVICE_ID, YOUR_TEMPLATE_ID, YOUR_PUBLIC_KEY
// 3. Add <script src="https://cdn.jsdelivr.net/npm/@emailjs/browser@3/dist/email.min.js"></script> to HTML

const bookForm = document.getElementById('bookForm');
bookForm?.addEventListener('submit', async function(e) {
  e.preventDefault();
  const btn = this.querySelector('.btn-submit');
  const success = document.getElementById('formSuccess');
  const original = btn.textContent;
  btn.textContent = 'Sending...';
  btn.disabled = true;

  // ── EmailJS option (recommended):
  /*
  try {
    await emailjs.send('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', {
      from_name: this.querySelector('[name="name"]').value,
      from_phone: this.querySelector('[name="phone"]').value,
      from_email: this.querySelector('[name="email"]').value,
      treatment: this.querySelector('[name="treatment"]').value,
      message: this.querySelector('[name="message"]').value,
    }, 'YOUR_PUBLIC_KEY');
    success.style.display = 'block';
    this.reset();
    btn.textContent = 'Sent ✓';
  } catch {
    btn.textContent = original;
    btn.disabled = false;
    alert('Something went wrong. Please call us directly.');
  }
  */

  // ── Formspree fallback (replace YOUR_FORM_ID):
  try {
    const res = await fetch('https://formspree.io/f/YOUR_FORM_ID', {
      method: 'POST',
      body: new FormData(this),
      headers: { 'Accept': 'application/json' }
    });
    if (res.ok) {
      success.style.display = 'block';
      this.reset();
      btn.textContent = 'Sent ✓';
    } else throw new Error();
  } catch {
    btn.textContent = original;
    btn.disabled = false;
    alert('Something went wrong. Please call us directly.');
  }
});

// ── SCROLL ANIMATIONS ──
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) entry.target.classList.add('visible');
  });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });

const style = document.createElement('style');
style.textContent = `
  .animate { opacity: 0; transform: translateY(24px); transition: opacity 0.6s ease, transform 0.6s ease; }
  .animate.visible { opacity: 1; transform: translateY(0); }
  .animate-delay-1 { transition-delay: 0.1s; }
  .animate-delay-2 { transition-delay: 0.2s; }
  .animate-delay-3 { transition-delay: 0.3s; }
`;
document.head.appendChild(style);

document.querySelectorAll(
  '.service-card, .testimonial-card, .welcome-content, .welcome-image-wrap, .mission-content, .gallery-item'
).forEach((el, i) => {
  el.classList.add('animate');
  if (i % 3 === 1) el.classList.add('animate-delay-1');
  if (i % 3 === 2) el.classList.add('animate-delay-2');
  observer.observe(el);
});

// ── ACTIVE NAV ──
const page = window.location.pathname.split('/').pop() || 'index.html';
document.querySelectorAll('.nav-link').forEach(link => {
  link.classList.toggle('active', link.getAttribute('href') === page);
});

// ── SMOOTH SCROLL ──
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    e.preventDefault();
    document.querySelector(a.getAttribute('href'))?.scrollIntoView({ behavior: 'smooth' });
  });
});
